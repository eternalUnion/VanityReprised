﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class RudeExporterSettings : ScriptableObject
{
	[Serializable]
	public class ItemEntry
	{
		public string parent = "";
		public int order = -1;
		public bool expanded = false;

		public bool isFolder = false;
		public string folderName = "New Folder";
		public string guid = "";
	}

	public static string DefaultBackupFolderPath
	{
		get => Path.GetFullPath("Backups");
	}

	public string buildPath = "";
	public bool promptBeforeExport = false;
	public bool summaryAfterExport = false;
	public bool checkForChanges = false;

	public bool enableBackups = true;
	public string backupPath = DefaultBackupFolderPath;
	public int maxBackupFolderSizeMB = 8192;
	public int maxSizePerBundleMB = 2048;

	public bool skipLegacyExporterRemoval = false;
	public List<string> legacyBundleLabelsToSkip = new List<string>();

	public List<ItemEntry> bundleTree = new List<ItemEntry>();
}
