using System;
using UnityEngine.ProBuilder.MeshOperations;
using Vertx.Debugging;

// This is a dummy class to support older version component of probuilder

namespace UnityEngine.ProBuilder.Shapes
{
	[AddComponentMenu("")]
	[DisallowMultipleComponent]
	internal sealed class ProBuilderShape : MonoBehaviour
	{
		[HideInInspector]
		[SerializeReference]
		private Object m_Shape = null;

		[HideInInspector]
		[SerializeField]
		private Vector3 m_Size = Vector3.one;

		[HideInInspector]
		[SerializeField]
		private Quaternion m_Rotation = Quaternion.identity;

		[HideInInspector]
		private ProBuilderMesh m_Mesh;

		[HideInInspector]
		[SerializeField]
		private PivotLocation m_PivotLocation;

		[HideInInspector]
		[SerializeField]
		private Vector3 m_PivotPosition;

		[HideInInspector]
		[SerializeField]
		internal ushort m_UnmodifiedMeshVersion;

		[HideInInspector]
		private Bounds m_EditionBounds;

		[HideInInspector]
		[SerializeField]
		private Bounds m_ShapeBox;
	}
}
