using System;
using System.Runtime.CompilerServices;

namespace Interop
{
	public struct InlineArray6<T> : IInlineArray<T>
	{
		private T t;

		private T _1;

		private T _2;

		private T _3;

		private T _4;

		private T _5;

		readonly int IInlineArray<T>.Length => 0;

		public unsafe readonly ref T this[int index] => ref Unsafe.NullRef<T>();

		public unsafe readonly ref T this[Index index] => ref Unsafe.NullRef<T>();

		public readonly Span<T> this[Range range] => default(Span<T>);

		public static implicit operator ReadOnlySpan<T>(in InlineArray6<T> array)
		{
			return default(ReadOnlySpan<T>);
		}

		public static implicit operator Span<T>(in InlineArray6<T> array)
		{
			return default(Span<T>);
		}
	}
}
