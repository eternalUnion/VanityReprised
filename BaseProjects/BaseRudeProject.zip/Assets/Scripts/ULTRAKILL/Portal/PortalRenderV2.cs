using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using ULTRAKILL.Portal.Native;
using Unity.Burst;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Rendering;

namespace ULTRAKILL.Portal
{
	[BurstCompile]
	public class PortalRenderV2 : MonoBehaviour
	{
		public struct OnscreenPortalData
		{
			public ushort handleIndex;

			public int depth;

			public int parentOnscreenIndex;

			public int depthSortedIndex;

			public float nearClip;
		}

		private struct Vertex
		{
			public float3 position;

			public half2 uv;

			public Vertex(float3 position, half2 uv)
			{
				this.position = default(float3);
				this.uv = default(half2);
			}
		}

		public enum PortalLightType
		{
			Player = 0,
			Enemy = 1,
			Environment = 2
		}

		public struct RenderData
		{
			public Vector3 viewPos;

			public Quaternion viewRot;

			public Matrix4x4 enterViewMatrix;

			public Matrix4x4 cullingMatrix;

			public Matrix4x4 parentViewMatrix;

			public ushort parentIndex;

			public ushort handleIndex;

			public ushort onscreenIndex;

			internal bool inMirroredSpace;

			internal bool canSeeItself;

			internal bool outMirroredSpace;

			internal int cullingMask;

			internal int depth;

			internal int maxDepth;

			internal bool useFog;

			internal Color fogColor;

			internal float fogStart;

			internal float fogEnd;

			internal float4 clipPlane;
		}

		public struct PrepassData
		{
			public int handleIndex;

			public ushort parentHandleIndex;

			public float4x4 viewMatrix;

			public ushort onscreenIndex;

			public bool inMirroredSpace;

			public float4 clipPlane;

			public PrepassData(int handleIndex, ushort parentHandleIndex, Matrix4x4 viewMatrix, ushort onscreenIndex, float4 clipPlane, bool inMirroredSpace)
			{
				this.handleIndex = 0;
				this.parentHandleIndex = 0;
				this.viewMatrix = default(float4x4);
				this.onscreenIndex = 0;
				this.inMirroredSpace = false;
				this.clipPlane = default(float4);
			}
		}

		public struct PortalView
		{
			public CameraData camData;

			public int depth;

			public int maxDepth;

			public ushort parentHandleIndex;

			public int parentOnscreenIndex;

			public int ignoreIndex;

			public bool inMirroredSpace;

			public float4x4 parentViewMatrix;

			public float4 clipPlane;

			public float4 parentClipPlane;

			public FogData lastFogData;
		}

		public struct DepthComparer : IComparer<int>
		{
			[ReadOnly]
			public NativeArray<OnscreenPortalData> Data;

			public int Compare(int a, int b)
			{
				return 0;
			}
		}

		internal unsafe delegate void RebuildMesh_000029FC_0024PostfixBurstDelegate(NativePortal* portalsSpan, in int spanLength, SubMeshDescriptor* subMeshes, ref Mesh.MeshData data);

		internal static class RebuildMesh_000029FC_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public unsafe static void Invoke(NativePortal* portalsSpan, in int spanLength, SubMeshDescriptor* subMeshes, ref Mesh.MeshData data)
			{
			}
		}

		internal unsafe delegate void BurstRenderData_000029FD_0024PostfixBurstDelegate(in NativePortalScene nativeScene, int mainCullingMask, in FogData defaultFogData, float maxDistance, float farClipPlane, int screenArea, float minPortalPixelArea, bool doOcclusionPass, in float4x4 defaultProjGPU, in float4x4 defaultProj, in float4x4 mirrorMatrix, ref NativeList<PortalView> portalViewStack, ref NativeList<PrepassData> prepass, ref NativeList<OnscreenPortalData> onscreenPortalData, ref NativeList<float4x4> cullingFrusta, ref NativeHashMap<int, ushort> textureStoreMap, float3* clipBufferA, float3* clipBufferB, float4* frustumPlanes, ref NativeList<RenderData> portalRenders);

		internal static class BurstRenderData_000029FD_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public unsafe static void Invoke(in NativePortalScene nativeScene, int mainCullingMask, in FogData defaultFogData, float maxDistance, float farClipPlane, int screenArea, float minPortalPixelArea, bool doOcclusionPass, in float4x4 defaultProjGPU, in float4x4 defaultProj, in float4x4 mirrorMatrix, ref NativeList<PortalView> portalViewStack, ref NativeList<PrepassData> prepass, ref NativeList<OnscreenPortalData> onscreenPortalData, ref NativeList<float4x4> cullingFrusta, ref NativeHashMap<int, ushort> textureStoreMap, float3* clipBufferA, float3* clipBufferB, float4* frustumPlanes, ref NativeList<RenderData> portalRenders)
			{
			}
		}

		internal delegate void SortPortals_000029FE_0024PostfixBurstDelegate(ref NativeArray<OnscreenPortalData> data, ref NativeArray<int> indices);

		internal static class SortPortals_000029FE_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public static void Invoke(ref NativeArray<OnscreenPortalData> data, ref NativeArray<int> indices)
			{
			}
		}

		internal unsafe delegate void ExtractFrustumPlanes_00002A00_0024PostfixBurstDelegate(float4x4* matrix, float4* planes);

		internal static class ExtractFrustumPlanes_00002A00_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public unsafe static void Invoke(float4x4* matrix, float4* planes)
			{
			}
		}

		internal unsafe delegate ushort GetOnscreenPortalsBurst_00002A01_0024PostfixBurstDelegate(in NativePortalScene scene, float3* enterPos, in float4x4 enterViewM, float4x4* enterCullM, float maxDistance, float farClipPlane, int ignoreIndex, int depth, int parentOnscreenIndex, float4* frustumPlanes, float3* clipBufferA, float3* clipBufferB, int screenArea, float minPortalPixelArea, in float4x4 defaultProjectionMatrix, ref NativeList<float4x4> cullingFrusta, ref NativeList<OnscreenPortalData> onscreenPortalData);

		internal static class GetOnscreenPortalsBurst_00002A01_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public unsafe static ushort Invoke(in NativePortalScene scene, float3* enterPos, in float4x4 enterViewM, float4x4* enterCullM, float maxDistance, float farClipPlane, int ignoreIndex, int depth, int parentOnscreenIndex, float4* frustumPlanes, float3* clipBufferA, float3* clipBufferB, int screenArea, float minPortalPixelArea, in float4x4 defaultProjectionMatrix, ref NativeList<float4x4> cullingFrusta, ref NativeList<OnscreenPortalData> onscreenPortalData)
			{
				return 0;
			}
		}

		internal unsafe delegate bool CalculateCullingData_00002A03_0024PostfixBurstDelegate(float3* clippedVerts, int count, in float4x4 enterViewM, in float4x4 proj, int screenArea, float areaThreshold, out float4 rectBounds, out float nearClip);

		internal static class CalculateCullingData_00002A03_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public unsafe static bool Invoke(float3* clippedVerts, int count, in float4x4 enterViewM, in float4x4 proj, int screenArea, float areaThreshold, out float4 rectBounds, out float nearClip)
			{
				rectBounds = default(float4);
				nearClip = default(float);
				return false;
			}
		}

		internal delegate void UpdateOcclusionBurst_00002A0B_0024PostfixBurstDelegate([NoAlias] ref NativeList<OnscreenPortalData> data, ulong bitset, [NoAlias] ref NativeArray<bool> visibility);

		internal static class UpdateOcclusionBurst_00002A0B_0024BurstDirectCall
		{
			private static IntPtr Pointer;

			private static IntPtr DeferredCompilation;

			[BurstDiscard]
			private static void GetFunctionPointerDiscard(ref IntPtr P_0)
			{
			}

			private static IntPtr GetFunctionPointer()
			{
				return (IntPtr)0;
			}

			public static void Constructor()
			{
			}

			public static void Initialize()
			{
			}

			public static void Invoke([NoAlias] ref NativeList<OnscreenPortalData> data, ulong bitset, [NoAlias] ref NativeArray<bool> visibility)
			{
			}
		}

		private const int EVENT_BEGIN_READBACK = 1001;

		private const int EVENT_FETCH_RESULTS = 1002;

		[Space(10f)]
		public bool doOcclusionPass;

		public Material portalCompositeMaterial;

		public Material portalMaterial;

		public Material portalBitset64DownsampleMat;

		public Material fakeRecursionCopy;

		public PortalScene scene;

		public float obliqueCutoff;

		public float minPortalPixelArea;

		private Plane[] frustumPlanes;

		private float4[] frustumPlanesF4;

		[HideInInspector]
		public Mesh totalPortalMesh;

		private Camera mainCam;

		private Camera portalCam;

		private NativeList<PrepassData> prepassPortals;

		private NativeList<RenderData> renderDatas;

		private CommandBuffer cb;

		private RenderTexture portalCompositeColor;

		private RenderTexture portalCompositeOutlineData;

		private RenderTargetIdentifier[] portalCompositeIdentifiers;

		private CommandBuffer recursionPortalDraw;

		private CommandBuffer bloodOilCB;

		private RenderTexture portalCompositeDepth;

		private RenderTargetIdentifier portalCompositeDepthIdentifier;

		[HideInInspector]
		public bool needsInit;

		private int lastWidth;

		private int lastHeight;

		private int screenArea;

		private PostProcessV2_Handler pph;

		[SerializeField]
		private Mesh occluderMesh;

		private RenderTexture portalOcclusionData;

		private RenderTargetIdentifier portalOcclusionDataIdentifier;

		private RenderTexture[] portalCompositeOcclusionData;

		private RenderTargetIdentifier[] portalCompositeOcclusionDataIdentifiers;

		private int bitsetMaxMip;

		public Texture2D testOcclusionMap;

		private float[] texArray;

		private AsyncGPUReadbackRequest occlusionReadback;

		private NativeList<OnscreenPortalData> onscreenPortalData;

		private NativeList<int> indexCache;

		private NativeList<float4x4> cullingFrusta;

		private float3[] clipBufferA;

		private float3[] clipBufferB;

		private int portalDepthID;

		private int portalOcclusionDataID;

		private int portalCompositeColorID;

		private int portalCompositeOutlineDatahID;

		private int portalDrawBitID;

		private int portalVPMatrixID;

		private int portalCompositeOcclusionDataID;

		private int InMirroredSpaceID;

		private int portalClipPlaneID;

		private int skipOcclusionDiscardID;

		private int portalCamForwardID;

		private List<Vertex> portalMeshVertices;

		private List<ushort> portalMeshIndices;

		private Matrix4x4 defaultProjectionMatrix;

		private Matrix4x4 defaultProjectionMatrixMirrored;

		private Matrix4x4 defaultProjectionMatrixGPU;

		private FogData defaultFogData;

		public static readonly int[] quadTriangleIndices;

		private static readonly ManualResetEventSlim waitHandle;

		private float maxDistance;

		private ulong occlusionBitset;

		private static float4x4 mirrorMatrix;

		private CommandBuffer mainPortalDraw;

		private List<(Light light, PortalLightType type)> tempPortalLights;

		private List<(Light light, PortalLightType type, Matrix4x4 travelMatrix, Vector4 portalPlane)> portalLights;

		private Vector4[] globalPortalLightPositions;

		private Vector4[] globalPortalLightColors;

		private Vector4[] globalPortalLightAttens;

		private Vector4[] globalPortalLightDirs;

		private Vector4[] globalPortalLightPlanes;

		private int portalLightCount;

		private Vector3[] reusableVerts;

		private NativeArray<bool> portalVisibility;

		private NativeHashMap<int, ushort> textureStoreMap;

		private static NativeList<PortalView> portalViewStack;

		private VertexAttributeDescriptor[] vertexDescriptor;

		private static Matrix4x4 identityMatrix;

		[DllImport("SameFrameReadback")]
		private static extern void BeginReadback_NonBlocking(IntPtr sourceTexture);

		[DllImport("SameFrameReadback")]
		private unsafe static extern void GetData_Blocking(long* result);

		[DllImport("SameFrameReadback")]
		private static extern IntPtr GetRenderEventFunc();

		[DllImport("SameFrameReadback")]
		private static extern IntPtr GetRenderEventAndDataFunc();

		private void Start()
		{
		}

		private void InitializeMesh()
		{
		}

		private void OnDisable()
		{
		}

		private void OnDestroy()
		{
		}

		public void Setup(PortalScene portalScene, Camera mainCamera, Camera portalCamera)
		{
		}

		private void MOCTestDrawScene()
		{
		}

		internal void AddPortalAwareLight(Light thisLight, PortalLightType lightType)
		{
		}

		private void UpdatePortalLights()
		{
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		private unsafe static void RebuildMesh(NativePortal* portalsSpan, in int spanLength, SubMeshDescriptor* subMeshes, ref Mesh.MeshData data)
		{
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		private unsafe static void BurstRenderData(in NativePortalScene nativeScene, int mainCullingMask, in FogData defaultFogData, float maxDistance, float farClipPlane, int screenArea, float minPortalPixelArea, bool doOcclusionPass, in float4x4 defaultProjGPU, in float4x4 defaultProj, in float4x4 mirrorMatrix, ref NativeList<PortalView> portalViewStack, ref NativeList<PrepassData> prepass, ref NativeList<OnscreenPortalData> onscreenPortalData, ref NativeList<float4x4> cullingFrusta, ref NativeHashMap<int, ushort> textureStoreMap, float3* clipBufferA, float3* clipBufferB, float4* frustumPlanes, ref NativeList<RenderData> portalRenders)
		{
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		public static void SortPortals(ref NativeArray<OnscreenPortalData> data, ref NativeArray<int> indices)
		{
		}

		public static void DebugFrustum(Matrix4x4 viewM, Matrix4x4 projM, Color color)
		{
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		public unsafe static void ExtractFrustumPlanes(float4x4* matrix, float4* planes)
		{
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		private unsafe static ushort GetOnscreenPortalsBurst(in NativePortalScene scene, float3* enterPos, in float4x4 enterViewM, float4x4* enterCullM, float maxDistance, float farClipPlane, int ignoreIndex, int depth, int parentOnscreenIndex, float4* frustumPlanes, float3* clipBufferA, float3* clipBufferB, int screenArea, float minPortalPixelArea, in float4x4 defaultProjectionMatrix, ref NativeList<float4x4> cullingFrusta, ref NativeList<OnscreenPortalData> onscreenPortalData)
		{
			return 0;
		}

		private static float4x4 Frustum(float l, float r, float b, float t, float n, float f)
		{
			return default(float4x4);
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		public unsafe static bool CalculateCullingData(float3* clippedVerts, int count, in float4x4 enterViewM, in float4x4 proj, int screenArea, float areaThreshold, out float4 rectBounds, out float nearClip)
		{
			rectBounds = default(float4);
			nearClip = default(float);
			return false;
		}

		private void DebugRect(float minX, float maxX, float minY, float maxY, float nearClip, Matrix4x4 enterViewMatrix)
		{
		}

		private void DestroyTextures()
		{
		}

		public void Initialize(bool forceInit = false)
		{
		}

		private Matrix4x4 MakeProjectionMatrixFlippedZ(Matrix4x4 proj)
		{
			return default(Matrix4x4);
		}

		private void DepthPrepass()
		{
		}

		private static void OnOcclusionReadbackCompleted(AsyncGPUReadbackRequest request)
		{
		}

		private static Vector4 IndexToBitMask(int index)
		{
			return default(Vector4);
		}

		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		public static void UpdateOcclusionBurst([NoAlias] ref NativeList<OnscreenPortalData> data, ulong bitset, [NoAlias] ref NativeArray<bool> visibility)
		{
		}

		public void Render(Camera cam)
		{
		}

		internal void SetPortalOcclusion(bool enabled)
		{
		}

		internal void GetOcclusionResults()
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal unsafe static void RebuildMesh_0024BurstManaged(NativePortal* portalsSpan, in int spanLength, SubMeshDescriptor* subMeshes, ref Mesh.MeshData data)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal unsafe static void BurstRenderData_0024BurstManaged(in NativePortalScene nativeScene, int mainCullingMask, in FogData defaultFogData, float maxDistance, float farClipPlane, int screenArea, float minPortalPixelArea, bool doOcclusionPass, in float4x4 defaultProjGPU, in float4x4 defaultProj, in float4x4 mirrorMatrix, ref NativeList<PortalView> portalViewStack, ref NativeList<PrepassData> prepass, ref NativeList<OnscreenPortalData> onscreenPortalData, ref NativeList<float4x4> cullingFrusta, ref NativeHashMap<int, ushort> textureStoreMap, float3* clipBufferA, float3* clipBufferB, float4* frustumPlanes, ref NativeList<RenderData> portalRenders)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal static void SortPortals_0024BurstManaged(ref NativeArray<OnscreenPortalData> data, ref NativeArray<int> indices)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal unsafe static void ExtractFrustumPlanes_0024BurstManaged(float4x4* matrix, float4* planes)
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal unsafe static ushort GetOnscreenPortalsBurst_0024BurstManaged(in NativePortalScene scene, float3* enterPos, in float4x4 enterViewM, float4x4* enterCullM, float maxDistance, float farClipPlane, int ignoreIndex, int depth, int parentOnscreenIndex, float4* frustumPlanes, float3* clipBufferA, float3* clipBufferB, int screenArea, float minPortalPixelArea, in float4x4 defaultProjectionMatrix, ref NativeList<float4x4> cullingFrusta, ref NativeList<OnscreenPortalData> onscreenPortalData)
		{
			return 0;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal unsafe static bool CalculateCullingData_0024BurstManaged(float3* clippedVerts, int count, in float4x4 enterViewM, in float4x4 proj, int screenArea, float areaThreshold, out float4 rectBounds, out float nearClip)
		{
			rectBounds = default(float4);
			nearClip = default(float);
			return false;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		[BurstCompile(CompileSynchronously = true, DisableSafetyChecks = true)]
		internal static void UpdateOcclusionBurst_0024BurstManaged([NoAlias] ref NativeList<OnscreenPortalData> data, ulong bitset, [NoAlias] ref NativeArray<bool> visibility)
		{
		}
	}
}
