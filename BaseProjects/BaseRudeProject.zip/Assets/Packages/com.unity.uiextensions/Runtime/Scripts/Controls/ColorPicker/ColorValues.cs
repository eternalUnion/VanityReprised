﻿///Credit judah4
///Sourced from - http://forum.unity3d.com/threads/color-picker.267043/

namespace UnityEngine.UI.Extensions.ColorPicker
{
    public enum ColorValues
    {
        R,
        G,
        B,
        A,

        Hue,
        Saturation,
        Value
    }
}