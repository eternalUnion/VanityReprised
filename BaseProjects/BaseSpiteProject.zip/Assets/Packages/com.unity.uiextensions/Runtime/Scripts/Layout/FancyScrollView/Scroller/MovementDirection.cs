﻿/// Credit setchi (https://github.com/setchi)
/// Sourced from - https://github.com/setchi/FancyScrollView

namespace UnityEngine.UI.Extensions
{
    public enum MovementDirection
    {
        Left,
        Right,
        Up,
        Down,
    }
}