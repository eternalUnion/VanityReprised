﻿using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
    public class HSVChangedEvent : UnityEvent<float, float, float>
    {

    }
}